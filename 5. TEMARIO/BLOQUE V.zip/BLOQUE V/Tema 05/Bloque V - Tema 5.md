# Tema 5 – Gastos y pagos especiales: anticipos de caja fija y pagos a justificar.

## Anticipos de Caja Fija

**Norma principal:** Real Decreto 725/1989, de 16 de junio.

**Artículos relevantes:**
- Arts. 1–3 – Concepto, naturaleza y finalidad
- Arts. 4–6 – Procedimiento de constitución y reposición
- Arts. 7–9 – Control y fiscalización de anticipos

## Pagos a justificar

**Norma principal:** Real Decreto 640/1987, de 8 de mayo.

**Artículos relevantes:**
- Arts. 1–4 – Concepto y supuestos de aplicación
- Arts. 5–7 – Procedimiento de expedición y reposición de fondos
- Arts. 8–10 – Justificación y rendición de cuentas

## Normativa complementaria

**Norma:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Arts. 78–85 – Disposiciones generales sobre pagos
- Arts. 88–94 – Procedimientos especiales de pago

---

## Observaciones
- Confirmar si existen órdenes ministeriales o resoluciones que actualicen el procedimiento de anticipos de caja fija o pagos a justificar.
- Verificar si la LGP ha introducido modificaciones posteriores que afecten a la regulación de estos pagos especiales.
