# Tema 6 – Gestión económica de contratos y subvenciones.

## Gestión económica de contratos

**Norma principal:** Ley 9/2017, de Contratos del Sector Público.

**Artículos relevantes:**
- Arts. 198–210 – Ejecución de los contratos y pago del precio
- Arts. 210–212 – Modificación de los contratos
- Arts. 213–215 – Extinción y liquidación de contratos

**Norma complementaria:** Real Decreto 1098/2001, de 12 de octubre, Reglamento General de la Ley de Contratos.

**Artículos relevantes:**
- Arts. 194–206 – Disposiciones económicas y de pago
- Arts. 207–214 – Modificaciones contractuales

## Gestión económica de subvenciones

**Norma principal:** Ley 38/2003, General de Subvenciones.

**Artículos relevantes:**
- Arts. 17–20 – Bases reguladoras y concesión
- Arts. 30–34 – Justificación de subvenciones
- Arts. 35–37 – Reintegro de subvenciones

**Norma complementaria:** Real Decreto 887/2006, Reglamento de la Ley General de Subvenciones.

**Artículos relevantes:**
- Arts. 30–40 – Procedimientos de concesión
- Arts. 60–70 – Procedimientos de justificación
- Arts. 91–96 – Procedimientos de reintegro

---

## Observaciones
- Verificar si existen órdenes ministeriales o resoluciones específicas para determinados tipos de contratos o subvenciones.
- Revisar si hay normativa europea que complemente la legislación nacional en materia de contratación pública y subvenciones.
