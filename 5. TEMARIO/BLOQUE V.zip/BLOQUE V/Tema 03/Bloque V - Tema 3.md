# Tema 3 – Procedimiento de gestión del gasto público: fases. Ordenación del gasto y ordenación del pago. Pago material.

## Procedimiento de gestión del gasto público: fases

**Norma principal:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Art. 73 – Disposiciones generales
- Art. 74 – Aprobación del gasto
- Art. 75 – Compromiso de gasto
- Art. 76 – Reconocimiento de la obligación
- Art. 77 – Propuesta de pago

## Ordenación del gasto

**Norma principal:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Arts. 75–76 – Competencias para ordenar el gasto

## Ordenación del pago

**Norma principal:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Art. 77 – Ordenación del pago
- Art. 78 – Competencias para ordenar el pago
- Art. 79 – Documentos contables y justificativos

## Pago material

**Norma principal:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Art. 80 – Ejecución material del pago
- Art. 81 – Justificación del pago
- Art. 82 – Responsabilidad en el pago
- Art. 83 – Pago por caja

---

## Normativa complementaria

**Norma:** Ley 39/2015, del Procedimiento Administrativo Común de las Administraciones Públicas

**Artículos relevantes:**
- Arts. 34–36 – Obligaciones de la Administración en materia de pagos
- Arts. 47–53 – Eficacia de actos administrativos

---

## Observaciones
- Confirmar si existen instrucciones internas del Ministerio de Hacienda que desarrollen el procedimiento de gestión y pago.
- Revisar si los artículos sobre fases del gasto han sido modificados en reformas recientes de la LGP.
