# Tema 1 – El presupuesto: concepto. Los principios presupuestarios. El ciclo presupuestario. El presupuesto por programas: concepto y fases. Terminología y desarrollo del proceso presupuestario.

## Concepto de presupuesto

**Norma principal:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Art. 2 – Ámbito de aplicación
- Art. 3 – Definición de Presupuesto

## Principios presupuestarios

**Norma principal:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Art. 4 – Principio de estabilidad presupuestaria
- Art. 5 – Principio de plurianualidad
- Art. 6 – Principio de transparencia
- Art. 7 – Principio de eficiencia en la asignación y utilización de recursos públicos
- Art. 8 – Principio de eficacia
- Art. 9 – Principio de unidad de caja
- Art. 10 – Principio de no afectación
- Art. 11 – Principio de especialidad cualitativa
- Art. 12 – Principio de especialidad cuantitativa
- Art. 13 – Principio de universalidad

## Ciclo presupuestario

**Norma principal:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Arts. 14–28 – Programación presupuestaria
- Arts. 29–42 – Elaboración y aprobación del presupuesto
- Arts. 43–73 – Gestión presupuestaria
- Arts. 74–83 – Liquidación y cierre

## Presupuesto por programas: concepto y fases

**Norma principal:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Art. 19 – Presupuesto por programas
- Art. 20 – Fases del presupuesto por programas

## Terminología y desarrollo del proceso presupuestario

**Norma principal:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Art. 5 – Terminología básica
- Arts. 14–28 – Programación presupuestaria
- Arts. 29–42 – Elaboración y aprobación
- Arts. 43–73 – Gestión presupuestaria
- Arts. 74–83 – Liquidación y cierre

---

## Normativa complementaria

**Norma:** Ley Orgánica 2/2012, de Estabilidad Presupuestaria y Sostenibilidad Financiera

**Artículos relevantes:**
- Arts. 3–12 – Principios de estabilidad, sostenibilidad y plurianualidad

---

## Observaciones
- Revisar la relación entre el principio de estabilidad presupuestaria (LGP, art. 4) y la LOEPSF.
- Confirmar si las modificaciones recientes de la LO 2/2012 afectan al contenido de los principios presupuestarios.
