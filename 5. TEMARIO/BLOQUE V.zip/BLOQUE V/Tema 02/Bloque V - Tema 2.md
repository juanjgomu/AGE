# Tema 2 – El presupuesto del Estado en España: concepto y estructura. Créditos presupuestarios: clasificación. Gastos plurianuales. Modificaciones presupuestarias.

## Concepto y estructura del presupuesto del Estado

**Norma principal:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Art. 34 – Concepto de Presupuestos Generales del Estado
- Art. 35 – Contenido
- Art. 36 – Principios de ordenación
- Arts. 37–39 – Estructuras presupuestarias

## Créditos presupuestarios: clasificación

**Norma principal:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Arts. 40–42 – Clasificación de créditos presupuestarios (económica, orgánica, funcional y por programas)

## Gastos plurianuales

**Norma principal:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Art. 47 – Autorización de gastos plurianuales
- Art. 48 – Limitaciones y condiciones

## Modificaciones presupuestarias

**Norma principal:** Ley 47/2003, General Presupuestaria

**Artículos relevantes:**
- Arts. 50–52 – Disposiciones generales sobre modificaciones de créditos
- Arts. 53–56 – Créditos extraordinarios y suplementos de crédito
- Art. 57 – Ampliaciones de crédito
- Art. 58 – Generaciones de crédito
- Arts. 59–60 – Transferencias de crédito
- Art. 61 – Incorporaciones de crédito
- Art. 62 – Anticipos de tesorería

---

## Normativa complementaria

**Norma:** Ley Orgánica 2/2012, de Estabilidad Presupuestaria y Sostenibilidad Financiera

**Artículos relevantes:**
- Art. 14 – Reglas para la autorización de gastos y modificaciones presupuestarias en el marco de estabilidad.

---

## Observaciones
- Confirmar si las leyes anuales de PGE establecen límites o condiciones específicas para las modificaciones de crédito.
- Verificar si las modificaciones presupuestarias requieren informes o autorizaciones adicionales según la LO 2/2012.
