# Tema 4 – Retribuciones e indemnizaciones por razón del servicio.

## Retribuciones

**Norma principal:** Real Decreto Legislativo 5/2015, de 30 de octubre, por el que se aprueba el texto refundido de la Ley del Estatuto Básico del Empleado Público (EBEP).

**Artículos relevantes:**
- Arts. 21–24 – Retribuciones básicas y complementarias
- Art. 25 – Retribuciones diferidas
- Art. 27 – Deducciones en nómina

**Norma complementaria:** Orden de 30 de julio de 1992 sobre instrucciones para la confección de nóminas.

**Contenido relevante:**
- Procedimientos de elaboración de nóminas
- Documentos justificativos y plazos

## Indemnizaciones por razón del servicio

**Norma principal:** Real Decreto 462/2002, de 24 de mayo.

**Artículos relevantes:**
- Arts. 1–4 – Ámbito de aplicación y tipos de indemnizaciones
- Arts. 5–10 – Indemnizaciones por desplazamientos
- Arts. 11–14 – Indemnizaciones por residencia y otras compensaciones
- Disposiciones adicionales y transitorias

---

## Observaciones
- Revisar actualizaciones en las cuantías de las indemnizaciones por razón del servicio mediante resoluciones anuales o modificaciones específicas del RD 462/2002.
- Confirmar si la Orden de confección de nóminas ha sido complementada con instrucciones internas más recientes en la AGE.
